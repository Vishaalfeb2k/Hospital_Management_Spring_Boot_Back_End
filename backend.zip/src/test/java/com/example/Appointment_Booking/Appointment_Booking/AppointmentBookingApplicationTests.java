package com.example.Appointment_Booking.Appointment_Booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
